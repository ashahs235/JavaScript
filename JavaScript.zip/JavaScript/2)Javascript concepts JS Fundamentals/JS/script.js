//objects -  day today life

//primitive datatypes
/*let name = "Dave";
let age = 20;
let isProgrammer = true;
let shipped = undefined;
let shopping;
let isPurchased = null; //initially empty, later value is assigned
//let isPurchased = "yes";*/

/*
//3 properties denoting a single person in real life 
let name = "Dave";
let age = 20;
let profession = "Developer";

//combine all 3 above variables are common for all, so combine them using object - {} used to denote objects
//JS Objects - key value pair - any kind of datatype can be combined in objects - personObject is defined
let personObject = 
{
    name : "Dave",
    age : 25,
    profession : "Developer",
    "last name" : "Johnson", //write later, "" is must for key with multiple words otherwise Uncaught SyntaxError: Unexpected identifier
    midName : "David",
    dateOfBirth : "08/01/1986"
}
console.log(personObject);

//extract any kind of variable from object - dot notation
console.log(personObject.age);
console.log(personObject.profession); */

/*extract any kind of variable from object - square bracket notation 
[] bcoz of space in variable declaration can't be accessed using dot operator
space is not valid syntax using dot notation */

/*
console.log(personObject["profession"]);
console.log(personObject.last name); // invalid - Uncaught SyntaxError: missing ) after argument list
console.log(personObject["last name"]); //[] for key as collection of words, []has object name before it

console.log(personObject.midName); //camel casing */

//Array - common (homogeneous) elements - [] to denote arrays
// let fruits = ["apples", "oranges","pears"]; //or numbers, index starts from 0 like roll no from 1
// //let fruits = ["apples", "oranges","pears", 45]; //possible but we don't do, arrays are homogeneous - 
// // only in JS (freedom), adding heterogeneous elements
// console.log(fruits);
// //console.log(fruits[0]); //1,2

// //Adding elements to the array - using index & built-in method
// //using index
// fruits[3] = "banana"; // if 0,1,2 value gets replaced 
// console.log(fruits);
// fruits[5] = "mango"; //5,6,7,8 - empty, empty*2,3,4
// console.log(fruits);
// fruits[4] = "watermelon"; //empty value gets replaced
// console.log(fruits);

// //using built-in method - bcoz adding extra element is ok if array is countable, 
// //empty value can be replaced if there are countable elements, if elements>50 then push method
// fruits.push("pineapple"); //element gets added at the END
// console.log(fruits); //better way than indexes, indexes to access values
// console.log(fruits[9]); //undefined - printing empty value - doesn't exist
// fruits.unshift("Mosambi"); //element gets added at the BEGINNING
// console.log(fruits); 

// fruits.pop(); //removes the element at the end of the array
// console.log(fruits); 

// //slice() : printing elements at a particular index - first & second values
// //elements at 1, 2, 3, 4 are printed, 5th element is not printed - from 1 to before 5
// console.log(fruits.slice(1, 5)); 

// let partOfFruits = fruits.slice(1, 4); //1st value is included & 2nd values is not included in a array
// console.log(partOfFruits);

// //Functions - in order not to repeat the code

// let number = 2;
// console.log(number * number);

// function squareOfNumber()
// {
//     let number = 2;
//     console.log(number * number);
// } 

// squareOfNumber();

//number is a input parameter - value passed to a function
// function squareOfNumber(number)
// {
//     console.log("the square of a number is");
//     console.log(number * number);
// } 

// function squareOfNumber(number)
// {
//     console.log("the square of a number is", number * number);
// } 

// function squareOfNumber(number)
// {
//     console.log("the square of a", number, "is", number * number);
// } 

//printing multiple variables in console.log -> using commas --console.log stmt can have collection of variables & strings
// function squareOfNumber(number)
// {
//     const square = number * number;
//     console.log("the square of a", number, "is", square);
//     console.log("thanks for using this function & printing square of a", number);
// } 

// //calling a function
// squareOfNumber(4);
// squareOfNumber(5);

// let isItemPurchased = null; //saree, null

// if(isItemPurchased)
// {
//     console.log("Shipped");
// }
// else
// {
//     console.log("Order will be shipped soon");
// }

// isItemPurchased = "saree"; //saree, null

// if(isItemPurchased)
// {
//     console.log("Shipped");
// }
// else
// {
//     console.log("Order will be shipped soon");
// }

function printOrderStatus(isItemAvailableInput)
{
    if(isItemAvailableInput)
    {
        console.log("Shipped");
    }
    else
    {
        console.log("Order will be shipped sooner.......");
    }
}

let isItemAvailable = null;
//printOrderStatus(isItemAvailable);

isItemAvailable = "saree";
printOrderStatus(isItemAvailable);

//===== functions are used to prevent repetition of code, & to perform particular task====

// //function with 2 parameters
// const pi = 3.14;
// // //let radius = 4;

// function areaOfCircle(valueOfPi, valueOfRadius)
// {
//     const area = valueOfPi * valueOfRadius * valueOfRadius;
//     console.log("area of circle is", area);
// }

// areaOfCircle(pi, 3); //1st value with 1st parameter & 2nd..
// areaOfCircle(pi, 5); 

//pi value can be taken directly
// const pi = 3.14;
// function areaOfCircle(valueOfRadius)
// {
//     const area = pi * valueOfRadius * valueOfRadius;
//     console.log("area of circle is", area);
// }

// areaOfCircle(3); //1st value with 1st parameter & 2nd..
// areaOfCircle(5); 

// //String methods - check whether name is present or not
// let name = "Dave Johnson";
// let name2 = "Joe Cartwright";
// let name3 = "Sandy Depp";
// //includes() is used to whether a particular string is present in parent input string -- case sensitive()
// console.log(name.includes("Johnson"));
// console.log(name.includes("John")); //son - true --part of the string
// console.log(name2.includes("Johnson"));
// console.log(name2.includes("Cart"));
// console.log(name2.includes("cart")); // case sensitive

// console.log(name.toLowerCase());
// console.log(name.toUpperCase());

//combine 2 strings

let firstName = "Mark";
let profession = "Developer";
let age = 20;
console.log(firstName, "is a", profession); //space is automatically concatinated

//combine strings using + sign
let completeString = firstName + profession;
console.log(completeString);
completeString = firstName + " is a " + profession;
console.log(completeString); //no longer preferred
completeString = firstName + " is a " + profession + " who is "+ age + " years of age "; // to avoid this, ``
console.log(completeString);

//`` -- string literal -- this is used to avoid too many + & ""
let newCompleteString = `${firstName} is a good ${profession} who is ${age} years old`; //easy
console.log(newCompleteString);

//for full stack development, array is d only data structure used, but for interview all DS -resume portfolio