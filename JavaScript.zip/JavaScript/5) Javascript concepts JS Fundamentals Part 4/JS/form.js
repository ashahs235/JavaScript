//function to handle click event of button -- (1)
function handleSubmitClick()
{
    //console.log("Button Clicked");
    const inputElement = document.getElementById("userNameInput");
    console.log("hi");
    console.log(inputElement, inputElement.value); //to access the value entered in textbox
    const inputElementValue = inputElement.value;
    const userNameOutputDiv = document.getElementById("userNameOutput");
   // userNameOutputDiv.innerText = inputElementValue;
    userNameOutputDiv.innerText = `The user typed ${inputElementValue} in the browser`;
    //value entered by user is sent back to server side
}

//2nd variation of onclick()
const buttonId = document.getElementById("submitButton"); //q#
//console.log(buttonId);
//syntax - object.onclick = function();
//buttonId.onclick = handleSubmitClick; //()X - no (),{} bcoz handleSubmitClick is passed as a value or parameter to onclick() 
//() for defining func, no() when a func is passed to some other click event - write only funct name

//addEventListener - particular listener watching for some event - click, mouseover, mouseenter
//eventListener listens to event to occur in code
//syntax - object.addEventListener("click", myScript);
buttonId.addEventListener("click", handleSubmitClick); //1st argument is click event, 2nd is func

