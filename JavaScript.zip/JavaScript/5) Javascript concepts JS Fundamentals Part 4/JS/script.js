//another way to access id
console.log(document.getElementById("userData")); //one way
console.log(document.querySelector("#userData")); //another way - without # - null
console.log(document.querySelector(".user-data-class")); 


//asynchronous nature of JS - time lag between client request & server response depending on net speed - fb, insta requests
//https://randomuser.me/api/?results=2
//JavaScript is a single-threaded programming language which means only one thing can happen at a time.
//That's where asynchronous JavaScript comes into play-- no continuation like d below 3 console.log stmts which r shown one by one
console.log("Statement 1");
console.log("Statement 2");
console.log("Statement 3"); //synchronous flow

//if it's like this
console.log("Statement 1");
console.log("Statement 2");
function fetchDataFromServer() //async
{
    //code to get data from server
    //one way => execute this func & then next stmt 
}// second way/efficient way => store the value in a queue, waits for server to return data, in d mean tym it run next stmt after the fetch data funct
//& does not wait for the server data back to the browser side bcoz lot of code running in JS, if a particular website keeps on waiting for a 
//particular Server request to get completed, that makes website loading process slower, solution is making func async in nature
//async - browser runs 1st 2 stmts, then it finds function fetchData block of code is trying to make a req to the browser or if there is some delay
//or if this function takes some tym to execute, it runs d code within this func & wait for the server to send data before moving forward in the func
//but it moves ahead with 3rd console.log stmt in d meantime. This is called asynchronous nature of JS
console.log("Statement 3");

//async keyword is used to tell d browser by developer that this funct takes tym to execute, so execute d stmts after this func & when 
//particular req is completed, then take the req block from the queue & pass it back to this func code
//aync in nature means some block of code need not run sequentially the way they're written, if there is delay -setTimeout()
//& takes tym to execute, browser won't wait for delay func to execute, it executes next stmts after the delay func till that server response is printed


//to make an api call - fetch, superagent, axios
console.log("Statement 1");
console.log("Statement 2");
const userDataDiv = document.querySelector("#userData");
async function fetchUserData() //asynchronous nature, not in regular execution
{
    const userDataRequest = await fetch("https://randomuser.me/api/?results=1") //results=3
    //fetch keyword is used to make a call to the server side or backend
    //await keyword  creates a promise which means it promises browser that 
    //the above url fetch request to get completed & waits for the server to pass on the data
    //so execute next stmts, don't wait so await()
    //time taking tasks are made asynchronous in nature using await keyword - it takes time, so move ahead & execute next stmts
    console.log(userDataRequest); //more data is not available in the console, it's in network tab - so JSON()
    let userDataJSON = await userDataRequest.json(); //write later - await keyword manages delays
    console.log(userDataJSON);  //network tab - response
    const firstName = userDataJSON.results[0].name.first;
    console.log(firstName); //random names
    userDataDiv.innerText = firstName;
}

//async await latest, earlier fetch, .then

fetchUserData() //await tells the browser not to wait for the server req to print on browser, execute the next stmts
//promise means whatever call is made to a browser or API, that url or req is executed some time later

console.log("Statement 3 -----");

//rt clk inspect console, elements tab, network tab - ?results=2 --response is previewed --more data is accessible in network tab
//so we go for json() - to get the proper response 

//Event - some kind of task/activity carried out by an user - click, hover etc