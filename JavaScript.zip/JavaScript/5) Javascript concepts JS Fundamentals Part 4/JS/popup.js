//alert("Hello");
const buttonElement = document.getElementById("popUpOpenButton");
//console.log(popUpOpenButton);

function handlePopUpButtonClick()
{
    const modalPopUpContainer = document.getElementById("modalContainer");
    console.log(modalPopUpContainer);
    console.log(modalPopUpContainer.style);
    modalPopUpContainer.style.display = "flex"; //display - none to flex
    
}

buttonElement.onclick = handlePopUpButtonClick;

const closeButtonElement = document.getElementById("closeButton");

function handleCloseButtonClick()
{
    const modalPopUpContainer = document.getElementById("modalContainer");
    console.log(modalPopUpContainer);
    modalPopUpContainer.style.display = "none";
}

closeButtonElement.onclick = handleCloseButtonClick;