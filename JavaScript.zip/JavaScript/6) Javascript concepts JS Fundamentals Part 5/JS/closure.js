//Closure - funct returns func
// function parentFunction()
// {
//     const a = 1;
//     const b = 2;
//     const c = 4;
//     //nested func or child func
//     function additionOfNumbers()
//     {
//         console.log("Inner func values", a, b, c);
//         return a + b + c; //values got stored in closure scope
//     }
//     console.log(c);
//     //return additionOfNumbers();  //inner func is executed 
//     return additionOfNumbers; //func is returned like return 4, return a
// }

// console.log(parentFunction); //raw func gets printed - printing the parent func
// console.log(" ");
// console.log(parentFunction()); //calling parent func
// console.log(" ");
//  const parentFunctionCall = parentFunction();
//  console.log(parentFunctionCall); //func body
 
// console.log(parentFunctionCall()); console.log(parentFunction()()); //- func call - func inside parent func is called -  so values got assigned
// console.log(parentFunction()());
//  console.dir(parentFunctionCall)
// const additionOfNumbers = parentFunction();
//  console.log(additionOfNumbers);
//  console.log(additionOfNumbers());
//  console.dir(additionOfNumbers)
//  console.dir(parentFunction);
//  console.dir(parentFunction());
// console.log("======================================================= ");

//Closure - 2nd example
/*function parentFunction1(firstNumber, secondNumber)
{
    //nested func
    function additionOfNumbers1()
    {
        console.log("Inner function values", firstNumber, secondNumber);
        return firstNumber + secondNumber;
    };
    //return additionOfNumbers1; //nested func is returned by a parent func - so closure is present
    return firstNumber; //no closure in scope
}
const sumOfNumbersFunction = parentFunction1(1, 2); 
//console.log(sumOfNumbersFunction);
//console.log(sumOfNumbersFunction()); //inner function is called
console.dir(sumOfNumbersFunction); console.dir(parentFunction1(1, 2)); 
console.dir(parentFunction1); 

//Closure - values are preserved in inner function bcoz (console.dir) JS has made scope of closure object & stored internally
//Closure - preserve the data passed in parent func to inner func
// -- nested (inner) func preserve the data of parent func when the inner func is called
//function should return function - nested func should be returned by parent func*/

//Closure 3
function additionTwo()
{
    function additionOfNumbers(inputNumber)
    {
        return inputNumber + 2;
    }
    return additionOfNumbers;
}

// const additionParentTwo = additionTwo();
// console.log(additionParentTwo); //raw func
// console.log(additionParentTwo(4));
// console.log(additionTwo()(5)); //(5)() - NaN
// console.log(" ");

// console.log("---------------------------------------------------------");
//Without Closure
/*function additionByTwo(input)
{
    return input + 2;
}

function additionByFour(input)
{
    return input + 4;
}

function additionBySix(input)
{
    return input + 6;
}
//left hand sides of above returns are same, only value changes
console.log(additionByTwo(3)); //() raw func
console.log(additionByFour(3));
console.log(additionBySix(3));
//use closure instead of 3 functions again & again
console.log("---------------------------------------------------------");*/
 
//Closure 4 - Classic example of y Closure in JS
function additionByANumber(adderValue)
{
    //nested funct
    function additionOfNumbers(inputNumber)
    {
        console.log("adder value", adderValue);
        console.log("input number", inputNumber);
        return inputNumber + adderValue;
    }
    return additionOfNumbers;
} //adderValue is constant & inputNumber keeps changing - Saurabh

const additionByTwo = additionByANumber(2); //2 is parent function adderValue parameter & got preserved
const additionByFour = additionByANumber(4); 
const additionBySix = additionByANumber(6);
console.log(additionByTwo); //function is expecting inner parameter
console.dir(additionByTwo); //2 is stored/preserved in adderValue in Closure Object
// console.dir(additionByFour);
// console.dir(additionBySix);
// console.dir("Add 6", additionBySix); //no concept of string concatenation like JSON object

// console.log(additionByTwo(10)); //input number parameter or below syntax
// console.log(additionByTwo(12));
 console.log(additionByANumber(3)(5)); // not a closure - currying function - first argument is outer func parameter & second is inner func
// console.log(additionByFour(5));
// console.log(additionBySix(4));

//Closures are used to build functions out of functions with some preserved data

