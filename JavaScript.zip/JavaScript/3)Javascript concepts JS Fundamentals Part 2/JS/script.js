//include method
let fruitsArray = ["apples", "banana", "papaya", "watermelon", "guava", "mango"];
let vegetablesArray = ["carrot", "potato", "onion"];
// console.log(fruitsArray.includes("banana")); //B - false - includes() is case sensitive
// console.log(fruitsArray.includes("guava"));
console.log(fruitsArray);
//console.log(fruitsArray, fruitsArray.length);
// console.log(fruitsArray[0]); //to print particular element from the array

//Array iteration - for loop is mechanism of incrementing index automatically instead of printing 0, 1, 2 like above 
for(let i in fruitsArray) //to print all the elements - i is a variable
{
    //console.log(i); //index is printed
    // console.log(fruitsArray);
    // console.log(fruitsArray[i]); //elements of array printed according to the index
    // console.log(i, fruitsArray[i]); //to access all the elements of the array
    //  const outputString = `The element at index ${i} is ${fruitsArray[i]}`;
    //  console.log(outputString); 
}

//syntax of for loop earlier --this loop can from d middle index=2, other loops start from d beginning
//for(let index = 0; index < fruitsArray.length; index++) //<=, = undefined, = is used to assign value to variable
//index<4,5... undefined if more than index.. but if array is big, last index is not known - .length
for(let index = 1; index < fruitsArray.length; index = index+2) //index<3
{
    const outputString = `The element at index ${index} is ${fruitsArray[index]} --old for loop`;
    //console.log(outputString);
    //console.log(index, fruitsArray.length);
}

for(let fruit of fruitsArray)
{
    //console.log(fruit); //directly elements are printed
    //const outputString = `The element at index is ${fruit}`;
    //console.log(outputString);
}

// function printAllElementsOfArray(inputArray) //--------map()
// {
//     for(let fruit of inputArray)
//     {
//         console.log(fruit); //directly elements are printed
//         const outputString = `The element at index is ${fruit}`;
//         console.log(outputString);
//     }
// }

// //Alternate function declaration
// function printAllElementsOfArray(inputArray)
// {
//     console.log("New array starts from here");
//     for(let i in inputArray) //variable inside for loop for iteration - mechanism to define iteratable index in a loop
//     {
//         const outputString = `The element at index ${i} is ${inputArray[i]}`;
//         console.log(outputString);
//     }
// }
 //printAllElementsOfArray(fruitsArray);
 //printAllElementsOfArray(vegetablesArray);


 //Map function - to iterate an array - built in function for arrays - in map, no parameter, func is parameter directly
 //like func for loop of syntax
//write func in map, no need to give func name bcoz func written/defined/given by map itself - called default functions
//--above declared functions are called name functions & functions with no name are called Default functions in JS 
//syntax is nameOfTheArray.map(function(){}) -- internally for loop syntax of

fruitsArray.map(function(fruit, index){ //func is returning a parameter fruit -- parameters can be of any names but they represent (1)elements/values & (2)indexes
    //console.log(`the new elemets are ${fruit} with index ${index}`); //directly printing elements
    const outputString = `The element at ${index} is ${fruit}`;
    console.log(outputString);
 });

 //OR
//not preferred
 function printElements(fruit, index)
 {
    const outputString = `The element at-- ${index} is ${fruit}`;
    console.log(outputString); 
 }
//fruitsArray.map(printElements);



//JSON object notation vs function
//func - group of stmts to perform particular task
//object contains all data types

function personDetails()
{
    let name = "Dave";
    let age=20;
    //these properties can't be accessed directly unless some code is written to return those values
}

let personObject = {
    name : "Dave",
    age=20
    //these values can be accessed directly using personObject.name
}



